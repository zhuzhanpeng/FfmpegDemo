package cn.jx.easyplayerlib.events;

/**
 *
 */

public interface VideoEventListener {

    void onResolutionChange(int width, int height);
}
