#EasyPlayer
A tiny weight player base on [FFmpeg](http://ffmpeg.org/) for Android.

##usage
Put your video file under root of your Android phone and just start EasyPlayer.

